const questions = [
  { q: "أطول نهر في العالم؟", a: "نهر النيل" },
  { q: "كم عدد الكواكب في النظام الشمسي؟", a: "8 كواكب" },
  { q: "أسرع حيوان على الأرض؟", a: "الفهد" },
  { q: "عاصمة الكويت؟", a: "مدينة الكويت" },
  { q: "ما هو الحيوان الذي لا ينام؟", a: "السمك" },
  { q: "ما هو العنصر الكيميائي الذي رمزه O؟", a: "الأكسجين" },
  { q: "كم يومًا في السنة الكبيسة؟", a: "366 يوم" },
  { q: "ما هو أكبر كوكب في النظام الشمسي؟", a: "المشتري" },
  { q: "ما اسم أسرع طائرة في العالم؟", a: "SR-71 Blackbird" },
  { q: "ما هو أسرع عضلة في جسم الإنسان؟", a: "الجفن" }
];

let current = null;
let score = 0;
let timer = null;
let timeLeft = 15;

const questionEl = document.getElementById("question");
const answerEl = document.getElementById("answer");
const scoreEl = document.getElementById("score");
const timerEl = document.getElementById("timer");
const newBtn = document.getElementById("newBtn");
const showBtn = document.getElementById("showBtn");

function startTimer() {
  clearInterval(timer);
  timeLeft = 15;
  timerEl.innerText = `⏱️ ${timeLeft}`;
  timer = setInterval(() => {
    timeLeft--;
    timerEl.innerText = `⏱️ ${timeLeft}`;
    if (timeLeft <= 0) {
      clearInterval(timer);
      showAnswer();
    }
  }, 1000);
}

function newQuestion() {
  current = questions[Math.floor(Math.random() * questions.length)];
  questionEl.innerText = current.q;
  answerEl.classList.add("hidden");
  answerEl.innerText = current.a;
  startTimer();
}

function showAnswer() {
  if (current) {
    answerEl.classList.remove("hidden");
    clearInterval(timer);
    score += 10;
    scoreEl.innerText = `النقاط: ${score}`;
  }
}

newBtn.addEventListener("click", newQuestion);
showBtn.addEventListener("click", showAnswer);